# AI News Bot
This bot fetches daily AI news and posts to Feishu.